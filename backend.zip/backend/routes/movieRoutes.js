import express from "express";
import { latestMovie,popularMovie,popularSeries,searchMovieAndSeries } from "../controllers/cineScopeController.js";

const router = express.Router();

router.get("/popular", popularMovie);
router.get("/latest", latestMovie);
router.get("/series",popularSeries);
router.get("/search",searchMovieAndSeries);
export default router;
